import boto3
from boto3.dynamodb.conditions import Key
import random
from datetime import datetime
import json

def lambda_handler(event, context):
    if event['httpMethod']=='GET':
        dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
        table = dynamodb.Table("fortunes")
        response = table.query(KeyConditionExpression=Key('type').eq("fortune"))
        return {
            'statusCode': 200,
            "headers": {
                "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
            },
            'body': json.dumps(response["Items"][random.randrange(0, response["Count"])])
        }
    elif event['httpMethod']=='POST':
        dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
        table = dynamodb.Table("fortunes")
        message = json.loads(event['body'])['message']
        response = table.put_item(
            Item={
                "type": "fortune",
                "message": message
            }
        )
        return {
            'statusCode': 200,
            "headers": {
                "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
            },
            'body': json.dumps(message)
        }

    return {
        'statusCode': 405,
        "headers": {
            "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
        },
        'body': json.dumps(event["httpMethod"])
    }

