import boto3
from boto3.dynamodb.conditions import Key
import random
from datetime import datetime
import json

def lambda_handler(event, context):
    if event['httpMethod']=='GET':
        dynamodb = boto3.resource("dynamodb",region_name="us-east-1")
        fortune_count = boto3.client('dynamodb', region_name="us-east-1").describe_table(TableName="fortunes")["Table"]["ItemCount"]
        # update after ItemCount returns correctly: fortune_id = random.randint(0, fortune_count-1)
        fortune_id = random.randint(0, fortune_count)
        fortune_table = dynamodb.Table("fortunes")
        day_fortune = fortune_table.query(KeyConditionExpression=Key('id').eq(fortune_id))["Items"][0]["message"]
        output = {"message":day_fortune}
        return {
            'statusCode': 200,
            "headers": {
                "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
            },
            'body': json.dumps(output)
        }
    elif event['httpMethod']=='POST':
        # dynamodb = boto3.resource("dynamodb",region_name="us-east-1")
        # table = dynamodb.Table("fortunes")
        # message = json.loads(event['body'])['message']
        # response = table.put_item(
        #     Item={
        #         "type": "fortune",
        #         "message": message
        #     }
        # )
        # return {
        #     'statusCode': 200,
        #     "headers": {
        #         "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
        #     },
        #     'body': json.dumps(message)
        # }
        return {
            'statusCode': 418,
            "headers": {
                "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
            },
            'body': "This endpoint has been temporarily disabled until a new feature is implemented"
        }

    return {
        'statusCode': 405,
        "headers": {
            "Access-Control-Allow-Origin": "https://www.ivandeveric.site"
        },
        'body': json.dumps(event["httpMethod"])
    }


