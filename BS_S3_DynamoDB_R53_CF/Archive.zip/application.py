from flask import Flask, jsonify, request, redirect
from flask_cors import CORS
import boto3
from boto3.dynamodb.conditions import Key
import random
from datetime import datetime

application = Flask(__name__)
CORS(application)
response = []
global latest_update

@application.route('/', methods=['GET'])
def fetch_homepage():
    return redirect("https://www.ivandeveric.site")

@application.route('/api/db/fortunes', methods=['GET'])
def fetch_data():
    global response
    global latest_update
    dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
    table = dynamodb.Table("fortunes")
    if not response:
        response = table.query(KeyConditionExpression=Key('type').eq("fortune"))
        latest_update = datetime.now()
    elif (datetime.now()-latest_update).seconds>300:
        latest_update=datetime.now()
        response = table.query(KeyConditionExpression=Key('type').eq("fortune"))
    return jsonify(response["Items"][random.randrange(0, response["Count"])])

@application.route('/api/db/fortunes', methods=['POST'])
def update_data():
    dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
    table = dynamodb.Table("fortunes")
    new_fortune = request.json

    update_response = table.put_item(
            Item={
                "type": "fortune",
                "message": new_fortune["message"]
            }
    )

    return jsonify({"message": "Data updated successfully", "updated_data": "sample text"})


if __name__ == '__main__':
    application.run()
