#!/bin/bash

apt update;
apt upgrade -y;
apt install python3-boto3 python3-flask python3-flask-cors -y;
ip=$(curl https://checkip.amazonaws.com);
sed -i -e "s/127.0.0.1/$ip/g" /home/admin/static/js/fortune.js;
python3 /home/admin/application.py
