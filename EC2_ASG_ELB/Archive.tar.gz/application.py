from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import boto3
from boto3.dynamodb.conditions import Key
import random

application = Flask(__name__)
CORS(application)

@application.route('/', methods=['GET'])
def fetch_homepage():
    return render_template("index.html")

@application.route('/api/db/getFortunes', methods=['GET'])
def fetch_data():
    dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
    table = dynamodb.Table("fortunes")
    response = table.query(KeyConditionExpression=Key('type').eq("fortune"))
    return jsonify(response["Items"][random.randrange(0, response["Count"])])

@application.route('/api/db/addFortune', methods=['PUT'])
def update_data():
    dynamodb = boto3.resource("dynamodb",region_name="eu-north-1")
    table = dynamodb.Table("fortunes")
    new_fortune = request.json

    response = table.put_item(
            Item={
                "type": "fortune",
                "message": new_fortune["message"]
            }
    )

    return jsonify({"message": "Data updated successfully", "updated_data": "sample text"})


if __name__ == '__main__':
    application.run(host="0.0.0.0")
