document.addEventListener("DOMContentLoaded", () => {
    fetch('http://127.0.0.1:5000/api/db/getFortunes')
        .then(response => response.json())
        .then(data => {
            document.getElementById("fortune").textContent=data.message
        })
        .catch(error => {
            console.error('Error fetching data:', error);
    });
    document.getElementById("fortune-button").addEventListener("click", () => {
        const fortuneInput = document.getElementById("fortune-input").value;
        const dataToUpdate = { "message": fortuneInput };
        fetch('http://127.0.0.1:5000/api/db/addFortune', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataToUpdate)
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById("confirm-insert").textContent="Success!";
        })
        .catch(error => {
            document.getElementById("confirm-insert").textContent="Failure!";
            console.error('Error updating data:', error);
        });
    });
});
